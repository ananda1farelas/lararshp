<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JenisHewan extends Model
{
    protected $table = 'jenis_hewan'; // nama tabel
    protected $primaryKey = 'idjenis_hewan'; // kolom primary key
    public $timestamps = false; // kalau tabel ga punya created_at & updated_at

    protected $fillable = [
        'nama_jenis_hewan'
    ];

    // Relasi ke tabel ras_hewan
    public function rasHewan()
    {
        return $this->hasMany(RasHewan::class, 'idjenis_hewan', 'idjenis_hewan');
    }
}
